import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by linuxian on 05/03/18.
 */
public class Noeud implements Comparable {
    static int qte = -1;
    int indice;
    int parent,prof,clSat, bool;
    char p;
    ArrayList<Integer> clau  = new ArrayList<Integer>();
    LinkedList<Integer> chemin = new LinkedList<>();

    public Noeud(int parent,char p,int clSat){
        qte++;
        this.indice = qte;
        this.p = p;
        this.parent = parent;
        this.clSat = clSat;
    }


    @Override
    public int compareTo(Object ob) {
        int nb = ((Noeud) ob).clSat;
        return nb-this.clSat;
    }

    public  void treatNode(Litteral clause[][],int nbcla,Litteral v){
        for (int i = 0; i < nbcla; i++)
            if(!Main.searchsatcl(this.clau,i)) {
                int k = 0;
                while (k < 3 && (clause[i][k].num != v.num || clause[i][k].val != v.val))
                    k++;
                if (k < 3) {
                    this.clSat++;
                    this.clau.add(i);
                }
            }

    }
}
