/**
 * Created by linuxian on 04/03/18.
 */
public class Litteral {
    int num;
    int val;

    public Litteral(int num, int val){
        this.num = num;
        this.val = val;
    }

    public int print(){
        if(this.val == 0) return (-1)*this.num;
        else return  this.num;
    }

}
