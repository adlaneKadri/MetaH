/**
 * Created by linuxian on 27/02/18.
 */
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        Litteral[][] clause;
        BufferedReader br = null;
        FileReader fr = null;
        File f;
        int d;
        //for(d=1;d<=5;d++) {
            //String str = "UUF75.325.100/uuf75-0"+d+".cnf";
            try {
                f = new File("UF75.325.100/uf75-04.cnf");
                fr = new FileReader(f);
                br = new BufferedReader(fr);
                String sCurrentLine;
                do {
                    sCurrentLine = br.readLine();
                } while (sCurrentLine.charAt(0) != 'p');
                sCurrentLine = sCurrentLine.replaceAll("\\s+", " ");
                String[] s = sCurrentLine.split(" ");
                int nbvar = Integer.parseInt(s[2]);
                int nbcla = Integer.parseInt(s[3]);
                clause = new Litteral[nbcla][3];
                int ind = 0;
                //System.out.println(nbvar+" "+nbcla);
                while ((sCurrentLine = br.readLine()) != null && ind != nbcla) {
                    sCurrentLine = sCurrentLine.replaceAll("\\s+", " ");
                    sCurrentLine = sCurrentLine.replaceAll("^ ", "");
                    s = sCurrentLine.split(" ");
                    int[] nume = new int[s.length];
                    for (int i = 0; i < s.length; i++) {
                        nume[i] = Integer.parseInt(s[i]);
                        //System.out.print(nume[i] + " ");
                    }  //System.out.println();
                    if (ind != nbcla) {
                        Litteral v;
                        for (int j = 0; j < 3; j++) {
                            if (nume[j] < 0) {
                                v = new Litteral(Math.abs(nume[j]), 0);
                                clause[ind][j] = v;
                            } else {
                                v = new Litteral(nume[j], 1);
                                clause[ind][j] = v;
                            }
                        }
                    }
                    ind++;
                }
                fr.close();
                /*System.out.println();
                System.out.println("**********************************************");
                System.out.println(str);*/
                //for (int k = 1; k <= 10; k++) {
                  // System.out.println("Itération : " + k);
                    dfs(clause, 1000, nbcla, nbvar);
                //}
                /*System.out.println();
                System.out.println("**********************************************");*/

            } catch (IOException e) {
                e.printStackTrace();
            }
        //}
    }

    public static boolean searchsatcl(ArrayList<Integer> cl, int i ){
        if(!cl.isEmpty()) {
            int taille = cl.size();
            int j = 0;
            while (j < taille && cl.get(j) != i)
                j++;
            if (j < taille) return true;
            else return false;
        }
        return false;
    }

    public static void dfs(Litteral[][] clause, long time, int nbcla, int nbvar){
        int fonction = 0;
        long startTime = System.currentTimeMillis();
        long testFinish = startTime + time;
        Noeud racine = new Noeud(-1,' ',0);
        racine.prof = 0;
        LinkedList<Noeud> open = new LinkedList<>();
        open.push(racine);
        //LinkedList<Noeud> clos = new LinkedList<Noeud>();
        ArrayList<Integer> ar = new ArrayList<>(); ar.add(0); ar.add(1);
        Random rand = new Random();
        int randomElement;
        while(fonction != nbcla && !open.isEmpty() && System.currentTimeMillis()<testFinish ){
            Collections.sort(open);
            /*System.out.println("\t******************");
            for(Noeud n : open) {
                Litteral vv = new Litteral(n.prof, n.bool);
                System.out.println(n.indice + " " + n.clSat + " " +vv.print());
            }
            System.out.println("\t******************");*/
            Noeud a = open.pop();
            Litteral v;
            if(a.indice !=0) {
               /*v = new Litteral(a.prof, a.bool);
                for (int i = 0; i < nbcla; i++) {
                    if(!searchsatcl(a.clau,i)) {
                        int k = 0;
                        while (k < 3 && (clause[i][k].num != v.num || clause[i][k].val != v.val))
                            k++;
                        if (k < 3) {
                            a.clSat++;
                            a.clau.add(i);
                        }
                    }
                }
                if(a.clSat>fonction)
                    fonction = a.clSat;*/
                //System.out.println(a.indice+" "+fonction);
            }
            if(a.prof<nbvar) {
                Noeud ng = new Noeud(a.indice, 'g',a.clSat);
                ng.prof = a.prof+1;
                ng.clau.addAll(a.clau);
                ng.chemin.addAll(a.chemin);
                randomElement = ar.get(rand.nextInt(ar.size()));
                ng.bool = randomElement;
                ar.remove(randomElement);
                v = new Litteral(ng.prof, ng.bool);
                ng.chemin.add(v.print());
                ng.treatNode(clause,nbcla,v);
                if(ng.clSat>fonction)
                    fonction = ng.clSat;
                
                Noeud nd = new Noeud(a.indice, 'd',a.clSat);
                nd.prof = a.prof+1;
                nd.clau.addAll(a.clau);
                nd.chemin.addAll(a.chemin);
                nd.bool = ar.get(0);
                v = new Litteral(nd.prof, nd.bool);
                nd.chemin.add(v.print());
                nd.treatNode(clause,nbcla,v);
                if(nd.clSat>fonction)
                    fonction = nd.clSat;
                
                ar.clear(); ar.add(0); ar.add(1);
                open.push(nd);
                open.push(ng);
            }
            //clos.add(a);
        }
        if(fonction == nbcla){
            Noeud n1 = open.pop();
            Noeud n2 = open.pop();
            if(n1.clSat != fonction)  n1 = n2;
            System.out.println("Satisfiable!!");
            for(Integer teger : n1.chemin)
                System.out.print(teger+" ");
        }
        else{
            float b = (float)fonction / (float) nbcla * 100;
            System.out.println(b+" %");
        }
        long stop = System.currentTimeMillis();
        long dur = stop-startTime;
        //System.out.println(dur);
    }
}
