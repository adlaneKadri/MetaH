/**
 * Created by linuxian on 05/03/18.
 */
public class Clause {

    int cl;
    boolean b;

}
