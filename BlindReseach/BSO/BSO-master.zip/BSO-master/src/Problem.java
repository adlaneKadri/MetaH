public interface Problem {
    <T> boolean isOptimal(T solution);
}
